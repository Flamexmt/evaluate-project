#!/bin/bash

wget https://zenodo.org/record/2581623/files/model_best.pth

