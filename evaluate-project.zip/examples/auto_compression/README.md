# Automated Compression

This directory contains example applications of various methods to automate the DNN compression process.<br>
We will slowly release implementations of these methods.

- ### [AMC - AutoML for Model Compression](./amc/README.md)